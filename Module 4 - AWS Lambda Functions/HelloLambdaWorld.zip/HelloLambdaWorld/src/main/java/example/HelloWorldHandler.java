package example;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class HelloWorldHandler implements RequestHandler<Request, Response> {

    public Response handleRequest(Request request, Context context) {
        String greetings = String.format("Hello %s of %s", request.getName(), request.getCity());
        return new Response(greetings);
    }
}

